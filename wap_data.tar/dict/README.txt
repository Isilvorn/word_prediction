The dictionary directory saves all data gathered on a specific word, which is stored in a file of the same name.
